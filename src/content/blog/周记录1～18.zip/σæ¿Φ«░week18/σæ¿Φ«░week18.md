---
title: 周记 Week 18
publishDate: 2026-02-10 22:04:56
description: "bruh"
tags:
 - personal
 - reflection
heroImage: { src: '139048088_p0_master1200.jpg', color: '#B4C6DA' }
---



## 学习

课内学习是真无趣


## 科研

速通了 Deep RL， 感觉不赖，下周开始可以速通llm然后继续project了，感觉自己的学习能力还是可以的


## 竞赛

摸


## 日常生活


作息还算健康，重新开始健身

打cs还是有点上头，不太行

## 总结

希望能继续保持吧，继续加油，专注自身


